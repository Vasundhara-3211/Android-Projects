package eu.tutorials.inheritanceapp

open class BaseClass {

    open fun role()
    {
        println("Member of the house coreValue");
    }



    fun coreValues()
    {
        println("This section contains the house coreValue")
    }
}