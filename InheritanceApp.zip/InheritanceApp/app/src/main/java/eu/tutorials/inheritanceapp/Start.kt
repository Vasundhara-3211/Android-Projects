package eu.tutorials.inheritanceapp

fun main()
{
    /* Concept of inheritance
    val obj1 = BaseClass()
    obj1.coreValues()

    val obj2 = Secondary()
    obj2.coreValues()


     */

    /* val obj1 = Secondary()
    obj1.role()

     */


    /* val obj1 = Tertiary()
    obj1.role()

     */


    val obj1 = Offspring()
    obj1.role()
    obj1.archery()
    obj1.sing()
    obj1.coreValues()
}