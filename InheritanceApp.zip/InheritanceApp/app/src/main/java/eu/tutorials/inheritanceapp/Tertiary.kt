package eu.tutorials.inheritanceapp

class Tertiary : BaseClass(){
    override fun role() {
        println("Bard of the house of the Baseclass")
    }
}