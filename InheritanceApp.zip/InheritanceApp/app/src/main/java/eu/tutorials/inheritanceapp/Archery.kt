package eu.tutorials.inheritanceapp

interface Archery {
    fun archery()
    {
        println("Archer skills from sir Secondary")
    }
}