package eu.tutorials.inheritanceapp

interface Singer {
    fun sing()
    {
        println("Singing skill from lady Tertiary")
    }
}