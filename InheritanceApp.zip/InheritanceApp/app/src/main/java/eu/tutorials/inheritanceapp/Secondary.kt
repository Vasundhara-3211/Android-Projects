package eu.tutorials.inheritanceapp

open class Secondary : BaseClass(){

    override fun role() {
//        super.role()
        println("Knight of the House BaseClass")
    }
}